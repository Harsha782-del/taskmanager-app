let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
    const taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    tasks.forEach((taskObj, index) => {
        const li = document.createElement("li");

        li.innerHTML = `
            <span style="text-decoration:${taskObj.completed ? 'line-through' : 'none'}">
                ${taskObj.text}
            </span>
            <div>
                <button onclick="toggleTask(${index})">✔</button>
                <button onclick="deleteTask(${index})">X</button>
            </div>
        `;

        taskList.appendChild(li);
    });
}

function addTask() {
    const input = document.getElementById("taskInput");
    const task = input.value.trim();

    if (task === "") return;
    tasks.push(task);
    saveTasks();
    renderTasks();



    input.value = "";
    tasks.push({ text: task, completed: false });
}

function deleteTask(index) {
    tasks.splice(index, 1);
    saveTasks();
    renderTasks();
}
function toggleTask(index) {
    tasks[index].completed = !tasks[index].completed;
    saveTasks();
    renderTasks();
}

// Load tasks on page load
renderTasks();